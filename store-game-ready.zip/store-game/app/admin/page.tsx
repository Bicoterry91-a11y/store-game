import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { redirect } from "next/navigation";

export default async function Admin() {
  const s=await getServerSession(authOptions); if(s?.user?.role!=="admin") redirect("/connexion");
  const [products,orders,users,paid]=await Promise.all([prisma.product.count(),prisma.order.count(),prisma.user.count(),prisma.order.aggregate({where:{paymentStatus:"paid"},_sum:{total:true}})]);
  return <div className="mx-auto max-w-7xl px-4 py-12"><h1 className="text-4xl font-black">Administration</h1><div className="mt-8 grid gap-4 md:grid-cols-4">{[["Produits",products],["Commandes",orders],["Clients",users],["CA payé",`${(paid._sum.total||0).toLocaleString("fr-FR")} XAF`]].map(([a,b])=><div key={a} className="card p-6"><p className="text-sm text-slate-500">{a}</p><p className="mt-2 text-3xl font-black">{b}</p></div>)}</div></div>;
}
