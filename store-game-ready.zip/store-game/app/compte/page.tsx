import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { redirect } from "next/navigation";

export default async function Compte() {
  const session = await getServerSession(authOptions);
  if (!session) redirect("/connexion");
  return <div className="mx-auto max-w-5xl px-4 py-12"><h1 className="text-4xl font-black">Mon compte</h1><div className="card mt-8 p-6"><p className="text-slate-400">Connecté en tant que</p><p className="mt-2 text-xl font-bold">{session.user.email}</p><div className="mt-6 flex gap-3"><a href="/commandes" className="rounded-xl border border-slate-700 px-4 py-3">Mes commandes</a><a href="/telechargements" className="rounded-xl border border-slate-700 px-4 py-3">Mes téléchargements</a></div></div></div>;
}
