import Image from "next/image";
import { notFound } from "next/navigation";
import { prisma } from "@/lib/prisma";
import { AddToCartButton } from "@/components/AddToCartButton";

export default async function ProductPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const product = await prisma.product.findUnique({ where: { slug } });
  if (!product) notFound();

  return <div className="mx-auto max-w-6xl px-4 py-10"><div className="grid gap-8 md:grid-cols-2">
    <div className="relative aspect-square overflow-hidden rounded-3xl border border-slate-800"><Image src={product.image} alt={product.name} fill className="object-cover" /></div>
    <div className="flex flex-col justify-center"><p className="text-sm uppercase tracking-widest text-cyan-400">{product.platform}</p><h1 className="mt-3 text-4xl font-black">{product.name}</h1><p className="mt-5 text-slate-300">{product.description}</p><div className="mt-7 text-3xl font-black">{product.price.toLocaleString("fr-FR")} XAF</div><div className="mt-7"><AddToCartButton product={{id: product.id, name: product.name, slug: product.slug, price: product.price, image: product.image}} /></div></div>
  </div></div>;
}
