"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

export default function Inscription() {
  const router=useRouter(); const [f,setF]=useState({name:"",email:"",password:""}); const [error,setError]=useState("");
  async function submit(e:React.FormEvent){e.preventDefault();setError("");const r=await fetch("/api/auth/register",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(f)});const d=await r.json();if(!r.ok){setError(d.error||"Erreur");return}router.push("/connexion");}
  return <div className="mx-auto max-w-md px-4 py-16"><div className="card p-8"><h1 className="text-3xl font-black">Créer un compte</h1><form onSubmit={submit} className="mt-6 space-y-4"><input required value={f.name} onChange={e=>setF({...f,name:e.target.value})} placeholder="Nom complet" className="w-full rounded-xl border border-slate-700 bg-slate-950 p-3"/><input required type="email" value={f.email} onChange={e=>setF({...f,email:e.target.value})} placeholder="Email" className="w-full rounded-xl border border-slate-700 bg-slate-950 p-3"/><input required minLength={8} type="password" value={f.password} onChange={e=>setF({...f,password:e.target.value})} placeholder="Mot de passe (8 caractères minimum)" className="w-full rounded-xl border border-slate-700 bg-slate-950 p-3"/><button className="w-full rounded-xl bg-white p-3 font-bold text-black">Créer mon compte</button>{error&&<p className="text-sm text-red-400">{error}</p>}</form></div></div>;
}
