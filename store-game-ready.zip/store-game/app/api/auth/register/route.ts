import { NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import { prisma } from "@/lib/prisma";

export async function POST(req: Request) {
  const {name,email,password}=await req.json();
  if(!name||!email||!password||password.length<8) return NextResponse.json({error:"Nom, email et mot de passe (8 caractères minimum) requis."},{status:400});
  const exists=await prisma.user.findUnique({where:{email}});
  if(exists) return NextResponse.json({error:"Ce compte existe déjà."},{status:409});
  const passwordHash=await bcrypt.hash(password,12);
  const user=await prisma.user.create({data:{name,email,passwordHash}});
  return NextResponse.json({id:user.id});
}
