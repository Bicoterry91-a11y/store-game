import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export async function GET(_: Request,{params}:{params:Promise<{id:string}>}) {
  const {id}=await params;
  const session=await getServerSession(authOptions);
  if(!session?.user?.id) return NextResponse.json({error:"Connexion requise."},{status:401});
  const order=await prisma.order.findFirst({
    where:{userId:session.user.id,paymentStatus:"paid",items:{some:{productId:id}}},
    include:{items:{where:{productId:id},include:{product:true}}}
  });
  if(!order) return NextResponse.json({error:"Produit non débloqué."},{status:403});
  const url=order.items[0]?.product.downloadUrl;
  if(!url) return NextResponse.json({error:"Téléchargement non configuré."},{status:404});
  return NextResponse.redirect(url);
}
