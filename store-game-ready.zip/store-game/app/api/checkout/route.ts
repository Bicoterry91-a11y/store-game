import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { createPayfusionPayment } from "@/lib/payfusion";

export async function POST(req: Request) {
  try {
    const body=await req.json();
    const items=Array.isArray(body.items)?body.items: [];
    const customer=body.customer;
    if(!items.length||!customer?.name||!customer?.email||!customer?.phone) return NextResponse.json({error:"Informations de commande incomplètes."},{status:400});

    const ids=items.map((i:{id:string})=>i.id);
    const products=await prisma.product.findMany({where:{id:{in:ids}}});
    const byId=new Map(products.map(p=>[p.id,p]));
    let total=0;
    const orderItems=[];
    for(const item of items){
      const p=byId.get(item.id);
      const qty=Math.max(1,Math.min(20,Number(item.quantity)||1));
      if(!p) return NextResponse.json({error:"Produit introuvable."},{status:400});
      total+=p.price*qty;
      orderItems.push({productId:p.id,quantity:qty,unitPrice:p.price});
    }

    const session=await getServerSession(authOptions);
    const reference=`SG-${Date.now()}-${Math.random().toString(36).slice(2,7).toUpperCase()}`;

    const order=await prisma.order.create({data:{
      userId:session?.user?.id||null,
      customerName:customer.name,
      customerEmail:customer.email,
      customerPhone:customer.phone,
      total,currency:"XAF",
      paymentReference:reference,
      paymentMethod:body.paymentMethod||"mobile_money",
      items:{create:orderItems}
    }});

    const payment=await createPayfusionPayment({
      amount:total,currency:"XAF",phone:customer.phone,reference,method:body.paymentMethod||"mobile_money"
    });

    return NextResponse.json({success:true,orderId:order.id,reference,paymentUrl:payment?.url||payment?.paymentUrl||null,payment});
  } catch(e) {
    return NextResponse.json({error:e instanceof Error?e.message:"Erreur serveur."},{status:500});
  }
}
