"use client";

import { signIn } from "next-auth/react";
import { useState } from "react";

export default function Connexion() {
  const [email,setEmail]=useState(""); const [password,setPassword]=useState(""); const [error,setError]=useState("");
  async function submit(e: React.FormEvent){e.preventDefault();setError("");const r=await signIn("credentials",{email,password,redirect:false});if(r?.error)setError("Email ou mot de passe incorrect.");else window.location.href="/compte";}
  return <div className="mx-auto max-w-md px-4 py-16"><div className="card p-8"><h1 className="text-3xl font-black">Connexion</h1><form onSubmit={submit} className="mt-6 space-y-4"><input type="email" required value={email} onChange={e=>setEmail(e.target.value)} placeholder="Email" className="w-full rounded-xl border border-slate-700 bg-slate-950 p-3"/><input type="password" required value={password} onChange={e=>setPassword(e.target.value)} placeholder="Mot de passe" className="w-full rounded-xl border border-slate-700 bg-slate-950 p-3"/><button className="w-full rounded-xl bg-white p-3 font-bold text-black">Se connecter</button>{error&&<p className="text-sm text-red-400">{error}</p>}</form></div></div>;
}
