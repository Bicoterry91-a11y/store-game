"use client";

import Link from "next/link";
import { useCartStore } from "@/store/cart-store";

export default function Panier() {
  const { items, setQuantity, removeItem } = useCartStore();
  const total = items.reduce((s, i) => s + i.price * i.quantity, 0);

  return <div className="mx-auto max-w-5xl px-4 py-10"><h1 className="text-4xl font-black">Panier</h1>{items.length === 0 ? <div className="card mt-8 p-10 text-center"><p className="text-slate-400">Votre panier est vide.</p><Link href="/boutique" className="mt-5 inline-block rounded-xl bg-white px-5 py-3 font-bold text-black">Continuer mes achats</Link></div> : <div className="mt-8 grid gap-6 lg:grid-cols-[1fr_320px]"><div className="space-y-3">{items.map(i => <div key={i.id} className="card flex items-center gap-4 p-4"><div className="flex-1"><p className="font-bold">{i.name}</p><p className="text-sm text-slate-500">{i.price.toLocaleString("fr-FR")} XAF</p></div><button className="border border-slate-700 px-3 py-1" onClick={() => setQuantity(i.id, i.quantity-1)}>-</button><span>{i.quantity}</span><button className="border border-slate-700 px-3 py-1" onClick={() => setQuantity(i.id, i.quantity+1)}>+</button><button onClick={() => removeItem(i.id)} className="text-sm text-red-400">Supprimer</button></div>)}</div><aside className="card h-fit p-6"><p className="text-slate-400">Total</p><p className="mt-2 text-3xl font-black">{total.toLocaleString("fr-FR")} XAF</p><Link href="/checkout" className="mt-6 block rounded-xl bg-gradient-to-r from-blue-600 to-violet-600 p-3 text-center font-bold">Passer au paiement</Link></aside></div>}</div>;
}
