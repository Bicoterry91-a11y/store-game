"use client";

import { useState } from "react";
import { useCartStore } from "@/store/cart-store";

export default function Checkout() {
  const { items, clear } = useCartStore();
  const total = items.reduce((s, i) => s + i.price * i.quantity, 0);
  const [form, setForm] = useState({ name: "", email: "", phone: "", method: "mobile_money" });
  const [message, setMessage] = useState("");
  const [loading, setLoading] = useState(false);

  async function pay() {
    setLoading(true); setMessage("");
    try {
      const res = await fetch("/api/checkout", { method: "POST", headers: {"Content-Type":"application/json"}, body: JSON.stringify({ items, customer: form, paymentMethod: form.method }) });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Erreur de paiement");
      if (data.paymentUrl) window.location.href = data.paymentUrl;
      else { clear(); setMessage("Paiement initié. Suivez les instructions envoyées par le prestataire."); }
    } catch (e) { setMessage(e instanceof Error ? e.message : "Une erreur est survenue."); }
    finally { setLoading(false); }
  }

  return <div className="mx-auto max-w-5xl px-4 py-10"><h1 className="text-4xl font-black">Paiement</h1><div className="mt-8 grid gap-6 md:grid-cols-2"><div className="card p-6 space-y-4">{(["name","email","phone"] as const).map(k => <input key={k} value={form[k]} onChange={e=>setForm({...form,[k]:e.target.value})} placeholder={k==="name"?"Nom complet":k==="email"?"Email":"Numéro de téléphone"} className="w-full rounded-xl border border-slate-700 bg-slate-950 p-3" />)}<select value={form.method} onChange={e=>setForm({...form,method:e.target.value})} className="w-full rounded-xl border border-slate-700 bg-slate-950 p-3"><option value="mobile_money">Mobile Money</option><option value="airtel_money">Airtel Money</option><option value="moov_money">Moov Money</option></select></div><div className="card h-fit p-6"><p className="text-slate-400">Total à payer</p><p className="mt-2 text-3xl font-black">{total.toLocaleString("fr-FR")} XAF</p><button disabled={loading || items.length===0} onClick={pay} className="mt-6 w-full rounded-xl bg-gradient-to-r from-blue-600 to-violet-600 p-3 font-bold disabled:opacity-50">{loading ? "Traitement..." : "Payer maintenant"}</button>{message && <p className="mt-4 text-sm text-cyan-300">{message}</p>}</div></div></div>;
}
