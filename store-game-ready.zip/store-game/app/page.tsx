import Link from "next/link";
import { prisma } from "@/lib/prisma";
import { ProductCard } from "@/components/ProductCard";

export default async function Home() {
  const products = await prisma.product.findMany({ orderBy: { createdAt: "desc" }, take: 8 });

  return (
    <div className="mx-auto max-w-7xl px-4 py-8">
      <section className="card overflow-hidden p-8 md:p-14">
        <div className="max-w-3xl">
          <span className="rounded-full border border-cyan-500/20 bg-cyan-500/10 px-3 py-1 text-xs uppercase tracking-widest text-cyan-300">Store Game</span>
          <h1 className="mt-5 text-5xl font-black leading-tight md:text-7xl"><span className="gradient-text">ACHETEZ. PAYEZ. RECEVEZ.</span></h1>
          <p className="mt-5 text-lg text-slate-300">Ton univers gaming, au même endroit.</p>
          <div className="mt-8 flex gap-3">
            <Link href="/boutique" className="rounded-xl bg-white px-6 py-3 font-bold text-black">Voir la boutique</Link>
            <Link href="/recherche" className="rounded-xl border border-slate-700 px-6 py-3 font-bold">Explorer</Link>
          </div>
        </div>
      </section>

      <section className="py-14">
        <div className="mb-6 flex items-end justify-between"><div><p className="text-sm text-cyan-400">CATALOGUE</p><h2 className="text-3xl font-black">Produits populaires</h2></div><Link href="/boutique" className="text-sm text-slate-400 hover:text-white">Tout voir →</Link></div>
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">{products.map(p => <ProductCard key={p.id} product={p} />)}</div>
      </section>

      <section className="grid gap-4 pb-16 md:grid-cols-3">
        {["Paiement rapide", "Produits numériques", "Support client"].map((x) => <div key={x} className="card p-6"><div className="text-lg font-bold">{x}</div><p className="mt-2 text-sm text-slate-400">Une expérience simple et pensée pour les joueurs.</p></div>)}
      </section>
    </div>
  );
}
