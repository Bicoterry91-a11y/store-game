import { prisma } from "@/lib/prisma";
import { ProductCard } from "@/components/ProductCard";

export default async function Boutique() {
  const products = await prisma.product.findMany({ orderBy: { createdAt: "desc" } });
  return <div className="mx-auto max-w-7xl px-4 py-10"><h1 className="text-4xl font-black">Boutique</h1><p className="mt-2 text-slate-400">Jeux, cartes cadeaux, crédits et produits numériques.</p><div className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">{products.map(p => <ProductCard key={p.id} product={p} />)}</div></div>;
}
