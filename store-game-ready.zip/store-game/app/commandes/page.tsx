import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { redirect } from "next/navigation";

export default async function Commandes() {
  const session=await getServerSession(authOptions); if(!session?.user?.id) redirect("/connexion");
  const orders=await prisma.order.findMany({where:{userId:session.user.id},include:{items:{include:{product:true}}},orderBy:{createdAt:"desc"}});
  return <div className="mx-auto max-w-5xl px-4 py-12"><h1 className="text-4xl font-black">Mes commandes</h1><div className="mt-8 space-y-3">{orders.length===0?<div className="card p-8 text-slate-400">Aucune commande.</div>:orders.map(o=><div key={o.id} className="card p-5"><div className="flex justify-between gap-4"><span className="font-bold">#{o.id.slice(-8)}</span><span className={o.paymentStatus==="paid"?"text-green-400":"text-yellow-400"}>{o.paymentStatus}</span></div><p className="mt-3 text-sm text-slate-400">{o.total.toLocaleString("fr-FR")} {o.currency}</p></div>)}</div></div>;
}
