import { prisma } from "@/lib/prisma";
import { ProductCard } from "@/components/ProductCard";

export default async function Recherche({ searchParams }: { searchParams: Promise<{q?: string}> }) {
  const {q=""}=await searchParams;
  const products=await prisma.product.findMany({where:q?{OR:[{name:{contains:q}},{category:{contains:q}},{platform:{contains:q}}]}:undefined,orderBy:{createdAt:"desc"}});
  return <div className="mx-auto max-w-7xl px-4 py-10"><h1 className="text-4xl font-black">Recherche</h1><p className="mt-2 text-slate-400">{q?`Résultats pour « ${q} »`:"Tous les produits"}</p><div className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">{products.map(p=><ProductCard key={p.id} product={p}/>)}</div></div>;
}
